Thanks for buying Pyxel Edit!

This archive contains both a portable, ready to run version that bundles the Adobe Air runtime,
and an installer that will install Air for you. Many people prefer the portable version, since 
it doesn't install Adobe Air. If you do not know which version to use then the installer is 
probably preferable because it associates .pyxel files with the program.

Happy pixelling!
