-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.62 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.3.0.4998
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table realmd.account
CREATE TABLE IF NOT EXISTS `account` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `username` varchar(32) NOT NULL,
  `sha_pass_hash` varchar(40) NOT NULL,
  `gmlevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sessionkey` longtext,
  `v` longtext,
  `s` longtext,
  `reg_mail` varchar(255) NOT NULL DEFAULT '',
  `token_key` varchar(100) NOT NULL DEFAULT '',
  `email` text,
  `joindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_ip` varchar(30) NOT NULL DEFAULT '0.0.0.0',
  `last_attempt_ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `last_local_ip` varchar(30) NOT NULL DEFAULT '127.0.0.1',
  `failed_logins` int(11) unsigned NOT NULL DEFAULT '0',
  `locked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `lock_country` varchar(2) NOT NULL DEFAULT '00',
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_pwd_reset` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `online` tinyint(4) NOT NULL DEFAULT '0',
  `expansion` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mutetime` bigint(40) NOT NULL DEFAULT '0',
  `mutereason` varchar(255) NOT NULL DEFAULT '',
  `muteby` varchar(50) NOT NULL DEFAULT '',
  `locale` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `os` varchar(4) NOT NULL DEFAULT '',
  `recruiter` int(11) NOT NULL DEFAULT '0',
  `current_realm` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `banned` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `mail_verif` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember_token` varchar(100) NOT NULL DEFAULT '',
  `flags` int(10) unsigned NOT NULL DEFAULT '0',
  `security` varchar(255) DEFAULT NULL,
  `pass_verif` varchar(255) DEFAULT NULL COMMENT 'Web recover password',
  `email_verif` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Email verification',
  `email_check` varchar(255) DEFAULT NULL,
  `nostalrius_token` varchar(255) DEFAULT NULL,
  `nostalrius_token_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `nostalrius_email` text,
  `nostalrius_reason` text,
  `geolock_pin` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`),
  KEY `idx_gmlevel` (`gmlevel`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Account System';

-- Dumping data for table realmd.account: ~1 rows (approximately)
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`id`, `username`, `sha_pass_hash`, `gmlevel`, `sessionkey`, `v`, `s`, `reg_mail`, `token_key`, `email`, `joindate`, `last_ip`, `last_attempt_ip`, `last_local_ip`, `failed_logins`, `locked`, `lock_country`, `last_login`, `last_pwd_reset`, `online`, `expansion`, `mutetime`, `mutereason`, `muteby`, `locale`, `os`, `recruiter`, `current_realm`, `banned`, `mail_verif`, `remember_token`, `flags`, `security`, `pass_verif`, `email_verif`, `email_check`, `nostalrius_token`, `nostalrius_token_enabled`, `nostalrius_email`, `nostalrius_reason`, `geolock_pin`) VALUES
	(1, 'ADMIN', '8301316D0D8448A34FA6D0C6BF1CBFA2B4A1A93A', 0, 'FC6B8719E55227B688C7C4F3239F823E03CA0CD962665544CF308427D7E0B6FF0F873352AECC318F', '674E0FDF712288C5709F2A16EA3008F1939263ECB1CD768E45DB29DB42EE81D1', '879030F33DD3A7774AD674CF0BF254B52BA66E3D65B87DA56652658C7D8709C7', '', '', NULL, '2018-11-12 21:59:21', '127.0.0.1', '127.0.0.1', '127.0.0.1', 0, 0, '00', '2020-05-04 00:01:59', '0000-00-00 00:00:00', 0, 0, 0, '', '', 0, 'niW', 0, 0, 0, 0, '', 0, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;


-- Dumping structure for table realmd.account_access
CREATE TABLE IF NOT EXISTS `account_access` (
  `id` int(11) unsigned NOT NULL,
  `gmlevel` tinyint(3) unsigned NOT NULL,
  `RealmID` int(11) NOT NULL,
  PRIMARY KEY (`id`,`RealmID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table realmd.account_access: ~1 rows (approximately)
/*!40000 ALTER TABLE `account_access` DISABLE KEYS */;
INSERT INTO `account_access` (`id`, `gmlevel`, `RealmID`) VALUES
	(1, 6, 1);
/*!40000 ALTER TABLE `account_access` ENABLE KEYS */;


-- Dumping structure for table realmd.account_banned
CREATE TABLE IF NOT EXISTS `account_banned` (
  `banid` bigint(20) NOT NULL AUTO_INCREMENT,
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Account id',
  `bandate` bigint(40) NOT NULL DEFAULT '0',
  `unbandate` bigint(40) NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `realm` tinyint(4) NOT NULL DEFAULT '1',
  `gmlevel` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`bandate`),
  UNIQUE KEY `banid` (`banid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Ban List';

-- Dumping data for table realmd.account_banned: 0 rows
/*!40000 ALTER TABLE `account_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_banned` ENABLE KEYS */;


-- Dumping structure for table realmd.antispam_blacklist
CREATE TABLE IF NOT EXISTS `antispam_blacklist` (
  `word` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table realmd.antispam_blacklist: 38 rows
/*!40000 ALTER TABLE `antispam_blacklist` DISABLE KEYS */;
INSERT INTO `antispam_blacklist` (`word`) VALUES
	('4GAMEPOWER'),
	('ELYSIUMAEWOW'),
	('ELYSIUMKYWOW'),
	('ELYSIUMORWOW'),
	('ELYSIUMRDWOW'),
	('ELYSIUMRSWOW'),
	('G4W@W'),
	('G4WOW'),
	('GOLD4MMO'),
	('GOLDCEO'),
	('GOLDDEAL'),
	('GOLDINSIDER'),
	('ILOVEUGOLD'),
	('ITEM4GAME'),
	('ITEM4WOW'),
	('MMOGO'),
	('MMOLORD'),
	('MMOOK'),
	('MMOSE'),
	('MMOTANK'),
	('MONEYFORGAMES'),
	('NOST100'),
	('NOST1OO'),
	('OKOGAME'),
	('OKOGAMES'),
	('OKOGOMES'),
	('PVPBANK'),
	('RNRNOOK'),
	('RNRNOSE'),
	('SELLNGOLD'),
	('SINBAGAME'),
	('SINBAGOLD'),
	('SINBAONLINE'),
	('SUSANGAME'),
	('WOWMARY'),
	('WTSITEM'),
	('X2GOLD'),
	('XIAOBAIMOSHOUJINGJI');
/*!40000 ALTER TABLE `antispam_blacklist` ENABLE KEYS */;


-- Dumping structure for table realmd.antispam_detected
CREATE TABLE IF NOT EXISTS `antispam_detected` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `detectScore` mediumint(5) NOT NULL DEFAULT '0',
  `detectTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `unmuteTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table realmd.antispam_detected: 0 rows
/*!40000 ALTER TABLE `antispam_detected` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_detected` ENABLE KEYS */;


-- Dumping structure for table realmd.antispam_replacement
CREATE TABLE IF NOT EXISTS `antispam_replacement` (
  `from` varchar(32) NOT NULL DEFAULT '',
  `to` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`from`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table realmd.antispam_replacement: 13 rows
/*!40000 ALTER TABLE `antispam_replacement` DISABLE KEYS */;
INSERT INTO `antispam_replacement` (`from`, `to`) VALUES
	('\\\\/\\\\/', 'W'),
	('/\\/\\', 'M'),
	('0', 'O'),
	('...hic!', ''),
	('()', 'O'),
	('\\/\\/', 'W'),
	('/\\\\', 'A'),
	('VV', 'W'),
	('@', 'O'),
	('/V\\', 'M'),
	('/\\\\/\\\\', 'M'),
	('㎜', 'MM'),
	('!<', 'K');
/*!40000 ALTER TABLE `antispam_replacement` ENABLE KEYS */;


-- Dumping structure for table realmd.antispam_scores
CREATE TABLE IF NOT EXISTS `antispam_scores` (
  `word` varchar(32) NOT NULL DEFAULT '',
  `score` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table realmd.antispam_scores: 58 rows
/*!40000 ALTER TABLE `antispam_scores` DISABLE KEYS */;
INSERT INTO `antispam_scores` (`word`, `score`, `type`) VALUES
	('>>', 1, 1),
	('<<', 1, 1),
	('5OG', 1, 1),
	('$', 2, 1),
	('MOTANK', 4, 0),
	('\\\\', 2, 1),
	('ACOUNT', 1, 0),
	('CHEAP', 2, 0),
	('LEVELING', 1, 0),
	('LEVLING', 1, 0),
	('LEVILING', 1, 0),
	('LVLING', 1, 0),
	('SAFE', 1, 0),
	('SERVICE', 1, 0),
	('NOST', 1, 0),
	('COM', 1, 0),
	('PRICE', 2, 0),
	('GOLD', 2, 0),
	('SKYPE', 2, 0),
	('EPIC', 2, 0),
	('DOLARS', 2, 0),
	('PROFESIONAL', 2, 0),
	('RELIABLE', 2, 0),
	('PROMOTION', 2, 0),
	('DELIVER', 2, 0),
	('NAX', 2, 0),
	('GAMES', 2, 0),
	('GRETINGS', 2, 0),
	('WEBSITE', 2, 0),
	('GOID', 2, 0),
	('ITEM4', 5, 1),
	('1OO', 2, 1),
	('POWER', 1, 0),
	('SELGOLD', 2, 0),
	('FAST', 1, 0),
	('25G', 2, 1),
	('981526249', 3, 1),
	('XIAOYUAN9921521', 3, 1),
	('MANFARM', 1, 1),
	('USD', 2, 0),
	('GWOW', 3, 0),
	('EUR', 2, 0),
	('80G', 1, 1),
	('OKO', 1, 0),
	('G4', 2, 1),
	('2OG', 1, 1),
	('MSD', 3, 0),
	('3VV', 3, 1),
	('3W', 2, 1),
	('SELL', 1, 1),
	('WVWOKO', 4, 0),
	('G=$', 3, 1),
	('1OG', 1, 0),
	('COIN', 0, 1),
	('P0VVER', 2, 1),
	('IEVEIING', 2, 1),
	('GO1D', 2, 1),
	('POWERLEVELING', 2, 0);
/*!40000 ALTER TABLE `antispam_scores` ENABLE KEYS */;


-- Dumping structure for table realmd.antispam_unicode
CREATE TABLE IF NOT EXISTS `antispam_unicode` (
  `from` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `to` mediumint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`from`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table realmd.antispam_unicode: 42 rows
/*!40000 ALTER TABLE `antispam_unicode` DISABLE KEYS */;
INSERT INTO `antispam_unicode` (`from`, `to`) VALUES
	(1063, 52),
	(1054, 79),
	(1057, 67),
	(1052, 77),
	(927, 79),
	(1050, 75),
	(913, 65),
	(917, 69),
	(1062, 85),
	(9675, 79),
	(1040, 65),
	(1058, 84),
	(1064, 87),
	(1025, 69),
	(1055, 78),
	(1065, 87),
	(922, 75),
	(924, 77),
	(1045, 69),
	(968, 87),
	(192, 65),
	(210, 79),
	(211, 79),
	(242, 79),
	(324, 78),
	(328, 78),
	(332, 79),
	(466, 79),
	(59336, 78),
	(12562, 84),
	(8745, 78),
	(65325, 77),
	(959, 79),
	(945, 65),
	(954, 75),
	(12295, 79),
	(65323, 75),
	(65296, 79),
	(65355, 75),
	(65357, 77),
	(65319, 71),
	(925, 78);
/*!40000 ALTER TABLE `antispam_unicode` ENABLE KEYS */;


-- Dumping structure for event realmd.DetectUpdate
DELIMITER //
CREATE DEFINER=`root`@`localhost` EVENT `DetectUpdate` ON SCHEDULE EVERY 1 MINUTE STARTS '2017-01-01 00:00:00' ON COMPLETION PRESERVE ENABLE DO BEGIN

        SELECT @time:= UNIX_TIMESTAMP();

        UPDATE `antispam_detected` SET `unmuteTime` = 0 WHERE @time > `unmuteTime`;

	    UPDATE `antispam_detected` SET `detectScore` = `detectScore` - 1 WHERE `detectScore` < 3 AND (@time - `detectTime`) > 7200;

	    DELETE FROM `antispam_detected` WHERE `detectScore` <= 0 AND (@time - `detectTime`) > 7200;

	END//
DELIMITER ;


-- Dumping structure for table realmd.geoip
CREATE TABLE IF NOT EXISTS `geoip` (
  `network_start_integer` int(11) DEFAULT NULL,
  `network_last_integer` int(11) DEFAULT NULL,
  `geoname_id` text,
  `registered_country_geoname_id` text,
  `represented_country_geoname_id` text,
  `is_anonymous_proxy` int(11) DEFAULT NULL,
  `is_satellite_provider` int(11) DEFAULT NULL,
  `postal_code` text,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `accuracy_radius` int(11) DEFAULT NULL,
  KEY `ip_start` (`network_start_integer`),
  KEY `ip_end` (`network_last_integer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table realmd.geoip: ~0 rows (approximately)
/*!40000 ALTER TABLE `geoip` DISABLE KEYS */;
/*!40000 ALTER TABLE `geoip` ENABLE KEYS */;


-- Dumping structure for table realmd.ip2nation
CREATE TABLE IF NOT EXISTS `ip2nation` (
  `ip` int(11) unsigned NOT NULL DEFAULT '0',
  `country` char(2) NOT NULL DEFAULT '',
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table realmd.ip2nation: ~0 rows (approximately)
/*!40000 ALTER TABLE `ip2nation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip2nation` ENABLE KEYS */;


-- Dumping structure for table realmd.ip2nationcountries
CREATE TABLE IF NOT EXISTS `ip2nationcountries` (
  `code` varchar(4) NOT NULL DEFAULT '',
  `iso_code_2` varchar(2) NOT NULL DEFAULT '',
  `iso_code_3` varchar(3) DEFAULT '',
  `iso_country` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(255) NOT NULL DEFAULT '',
  `lat` float NOT NULL DEFAULT '0',
  `lon` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`code`),
  KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table realmd.ip2nationcountries: ~0 rows (approximately)
/*!40000 ALTER TABLE `ip2nationcountries` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip2nationcountries` ENABLE KEYS */;


-- Dumping structure for table realmd.ip_banned
CREATE TABLE IF NOT EXISTS `ip_banned` (
  `ip` varchar(32) NOT NULL DEFAULT '0.0.0.0',
  `bandate` int(11) NOT NULL,
  `unbandate` int(11) NOT NULL,
  `bannedby` varchar(50) NOT NULL DEFAULT '[Console]',
  `banreason` varchar(50) NOT NULL DEFAULT 'no reason',
  PRIMARY KEY (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Banned IPs';

-- Dumping data for table realmd.ip_banned: 0 rows
/*!40000 ALTER TABLE `ip_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_banned` ENABLE KEYS */;


-- Dumping structure for table realmd.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table realmd.migrations: 0 rows
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;


-- Dumping structure for table realmd.realmcharacters
CREATE TABLE IF NOT EXISTS `realmcharacters` (
  `realmid` int(11) unsigned NOT NULL DEFAULT '0',
  `acctid` bigint(20) unsigned NOT NULL,
  `numchars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`realmid`,`acctid`),
  KEY `acctid` (`acctid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Realm Character Tracker';

-- Dumping data for table realmd.realmcharacters: 1 rows
/*!40000 ALTER TABLE `realmcharacters` DISABLE KEYS */;
INSERT INTO `realmcharacters` (`realmid`, `acctid`, `numchars`) VALUES
	(1, 1, 2);
/*!40000 ALTER TABLE `realmcharacters` ENABLE KEYS */;


-- Dumping structure for table realmd.realmlist
CREATE TABLE IF NOT EXISTS `realmlist` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `address` varchar(32) NOT NULL DEFAULT '127.0.0.1',
  `localAddress` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localSubnetMask` varchar(255) NOT NULL DEFAULT '255.255.255.0',
  `port` int(11) NOT NULL DEFAULT '8085',
  `icon` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `realmflags` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `timezone` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowedSecurityLevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `population` float unsigned NOT NULL DEFAULT '0',
  `gamebuild_min` int(11) unsigned NOT NULL DEFAULT '0',
  `gamebuild_max` int(11) unsigned NOT NULL DEFAULT '0',
  `flag` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `realmbuilds` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Realm System';

-- Dumping data for table realmd.realmlist: 1 rows
/*!40000 ALTER TABLE `realmlist` DISABLE KEYS */;
INSERT INTO `realmlist` (`id`, `name`, `address`, `localAddress`, `localSubnetMask`, `port`, `icon`, `realmflags`, `timezone`, `allowedSecurityLevel`, `population`, `gamebuild_min`, `gamebuild_max`, `flag`, `realmbuilds`) VALUES
	(1, 'Lightbringer', '127.0.0.1', '127.0.0.1', '255.255.255.0', 8085, 1, 0, 1, 0, 0.02, 0, 0, 2, '5875 6005 6141 ');
/*!40000 ALTER TABLE `realmlist` ENABLE KEYS */;


-- Dumping structure for table realmd.uptime
CREATE TABLE IF NOT EXISTS `uptime` (
  `realmid` int(11) unsigned NOT NULL,
  `starttime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `startstring` varchar(64) NOT NULL DEFAULT '',
  `uptime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `onlineplayers` smallint(5) unsigned NOT NULL DEFAULT '0',
  `maxplayers` smallint(5) unsigned NOT NULL DEFAULT '0',
  `revision` varchar(255) NOT NULL DEFAULT 'Trinitycore',
  PRIMARY KEY (`realmid`,`starttime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Uptime system';

-- Dumping data for table realmd.uptime: 26 rows
/*!40000 ALTER TABLE `uptime` DISABLE KEYS */;
INSERT INTO `uptime` (`realmid`, `starttime`, `startstring`, `uptime`, `onlineplayers`, `maxplayers`, `revision`) VALUES
	(1, 1542052733, '2018-11-12 21:58:53', 0, 0, 0, 'Trinitycore'),
	(1, 1542052857, '2018-11-12 22:00:57', 0, 0, 0, 'Trinitycore'),
	(1, 1542052959, '2018-11-12 22:02:39', 0, 0, 0, 'Trinitycore'),
	(1, 1542053043, '2018-11-12 22:04:03', 0, 0, 0, 'Trinitycore'),
	(1, 1542053072, '2018-11-12 22:04:32', 0, 0, 0, 'Trinitycore'),
	(1, 1549739429, '2019-02-09 21:10:29', 0, 0, 0, 'Trinitycore'),
	(1, 1549739612, '2019-02-09 21:13:32', 0, 0, 0, 'Trinitycore'),
	(1, 1549739695, '2019-02-09 21:14:55', 0, 0, 0, 'Trinitycore'),
	(1, 1549742132, '2019-02-09 21:55:32', 0, 0, 0, 'Trinitycore'),
	(1, 1549742165, '2019-02-09 21:56:05', 0, 0, 0, 'Trinitycore'),
	(1, 1549742186, '2019-02-09 21:56:26', 0, 0, 0, 'Trinitycore'),
	(1, 1561304097, '2019-06-23 18:34:57', 0, 0, 0, 'Trinitycore'),
	(1, 1561304164, '2019-06-23 18:36:04', 0, 0, 0, 'Trinitycore'),
	(1, 1561304694, '2019-06-23 18:44:54', 0, 0, 0, 'Trinitycore'),
	(1, 1561304714, '2019-06-23 18:45:14', 0, 0, 0, 'Trinitycore'),
	(1, 1561304740, '2019-06-23 18:45:40', 0, 0, 0, 'Trinitycore'),
	(1, 1561305854, '2019-06-23 19:04:14', 0, 0, 0, 'Trinitycore'),
	(1, 1561306248, '2019-06-23 19:10:48', 0, 0, 0, 'Trinitycore'),
	(1, 1561306258, '2019-06-23 19:10:58', 0, 0, 0, 'Trinitycore'),
	(1, 1561306269, '2019-06-23 19:11:09', 0, 0, 0, 'Trinitycore'),
	(1, 1561810116, '2019-06-29 15:08:36', 0, 0, 0, 'Trinitycore'),
	(1, 1561810388, '2019-06-29 15:13:08', 0, 0, 0, 'Trinitycore'),
	(1, 1575223967, '2019-12-01 20:12:47', 0, 0, 0, 'Trinitycore'),
	(1, 1588529664, '2020-05-03 21:14:24', 0, 0, 0, 'Trinitycore'),
	(1, 1588539555, '2020-05-03 23:59:15', 0, 0, 0, 'Trinitycore'),
	(1, 1588539692, '2020-05-04 00:01:32', 0, 0, 0, 'Trinitycore');
/*!40000 ALTER TABLE `uptime` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
